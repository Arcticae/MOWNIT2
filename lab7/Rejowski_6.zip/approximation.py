import numpy as np
import matplotlib.pyplot as plt
import os


def f(x):
    return np.exp(-3 * np.sin(2 * x))


def get_d(xpts, degree):
    n = len(xpts)
    D = np.zeros((n, degree))
    for i in range(n):
        for j in range(degree):
            D[i][j] = xpts[i] ** j

    return D


def get_coeffs(nodes, degree):
    xs = [node[0] for node in nodes]
    ys = [node[1] for node in nodes]
    D = get_d(xs, degree)
    Dt = np.transpose(D)
    DtD = np.dot(Dt, D)
    invDtD = np.linalg.inv(DtD)  # we inverse the matrix
    return np.dot(invDtD, (np.dot(Dt, ys)))  # where the magic happens


def plot_result(original, nodes, result, degree):
    origxs = [p[0] for p in original]
    origys = [p[1] for p in original]
    nodesx = [p[0] for p in nodes]
    nodesy = [p[1] for p in nodes]
    # resx = [p[0] for p in result]
    resy = [p[1] for p in result]

    plt.plot(origxs, origys, c='olive')
    plt.plot(origxs, resy, c='red')
    plt.scatter(nodesx, nodesy, c='black')
    plt.grid(True)
    dir = "./plots"
    if not os.path.exists(dir):
        os.mkdir(dir)
    dir += '/degree=' + str(degree) + '/'
    if not os.path.exists(dir):
        os.mkdir(dir)
    plt.savefig(dir + "nodes=" + str(len(nodes)) + ".pdf")
    plt.close()


def approximate(coeffs, x):
    res = 0.0
    for i in range(len(coeffs)):
        res += coeffs[i] * (pow(x, i))
    return res


def main():
    n = 15  # how many points we want to map
    resolution = 1000  # how big the plot's resolution will be
    degree = 10  # degree of the interpolation polynomial - 1. it means 2 is a line function 3 is quadratic etc...

    xdraw = np.linspace(0, 3 * np.pi, resolution)
    ydraw = [f(xpt) for xpt in xdraw]

    drawn = list(zip(xdraw, ydraw))

    # coeffs = get_coeffs(nodes, degree) #we get the coeffitients of a polynomial of wanted degree
    # yres = [approximate(coeffs, xpt) for xpt in xdraw]
    # result = list(zip(xdraw, yres))

    print("deg;nodes;eucl_dist")
    for n in range(4, 30, 1):  # we change the number of nodes, from 4 to 15 (n)
        for i in range(4, n+1, 1):  # we change the degree of polynomial from 4 to 9 (i)
            diffs = []
            xnodes = np.linspace(0, 3 * np.pi, n)
            ynodes = [f(xnode) for xnode in xnodes]
            nodes = list(zip(xnodes, ynodes))
            coeffs = get_coeffs(nodes, i)
            yres = [approximate(coeffs, xpt) for xpt in xdraw]
            result = list(zip(xdraw, yres))
            for ind in range(len(xdraw)):
                diffs.append((ydraw[ind] - yres[ind]) ** 2)
            print(str(i) + ";" + str(n) + ";" + str((sum(diffs) / len(diffs)) ** (1 / 2)))
            plot_result(drawn, nodes, result, i)


if __name__ == "__main__":
    main()
    exit(0)
